#!/usr/bin/env bash
# mark executable: chmod +x install.sh
pip install git+https://github.com/toddrob99/MLB-StatsAPI.git@1.9.0
